Cada carpeta se corresponde con un ejercicio dentro del tema.
En el javadoc de cada archivo main de cada ejercicio, 
indica la pagina a la que pertenece.

Aunque el ejercicio propuesto que cuenta es "Actividad3"
