package org.vawacode;

/**
 * Pag. 10
 * En JDBCHelper, implementa una función estática para saber si
 * el nombre de una tabla existe en una base de datos
 *
 * public static boolean containsTable(Connection con, String tableName)
 */

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}